import os
from dotenv import load_dotenv
from flask import Flask

load_dotenv()  # lee los datos del archivo .env

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY")